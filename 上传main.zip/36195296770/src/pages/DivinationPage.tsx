import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CoinDivination from "@/components/divination/CoinDivination";
import TimeDivination from "@/components/divination/TimeDivination";
import RandomDivination from "@/components/divination/RandomDivination";
import DayanDivination from "@/components/divination/DayanDivination";
import { generateHexagram } from "@/lib/mockData";
import { toast } from "sonner";

export default function DivinationPage() {
  const [activeTab, setActiveTab] = useState<"coin" | "time" | "random" | "dayan">("coin");
  const [result, setResult] = useState<number | null>(null);
  const navigate = useNavigate();

  const handleDivinationComplete = (hexagramId: number) => {
    try {
      if (hexagramId >= 1 && hexagramId <= 64) {
        setResult(hexagramId);
        saveDivinationRecord(hexagramId, activeTab);
        toast.success("占卜完成！");
      } else {
        toast.error("占卜结果无效，请重试");
      }
    } catch (error) {
      console.error("处理占卜结果时出错:", error);
      toast.error("处理占卜结果时出错");
    }
  };

  const saveDivinationRecord = (hexagramId: number, method: string) => {
    const records = JSON.parse(localStorage.getItem("divinationRecords") || "[]");
    records.unshift({
      id: Date.now(),
      hexagramId,
      method,
      date: new Date().toISOString()
    });
    localStorage.setItem("divinationRecords", JSON.stringify(records));
  };

  const handleViewInterpretation = () => {
    if (result && result >= 1 && result <= 64) {
      navigate(`/hexagram/${result}`);
    } else {
      toast.error("无法查看无效的卦象");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#1A1A1A]">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-4xl font-serif font-bold text-[#9C6A4B] mb-8 text-center">
          易经占卜
        </h1>
        
        {/* 占卜方式选项卡 */}
        <div className="flex border-b border-[#9C6A4B] mb-8 overflow-x-auto">
          <button
            className={`py-2 px-4 font-serif whitespace-nowrap ${activeTab === "coin" ? "text-white border-b-2 border-[#9C6A4B]" : "text-[#9C6A4B]"}`}
            onClick={() => setActiveTab("coin")}
          >
            金钱卦
          </button>
          <button
            className={`py-2 px-4 font-serif whitespace-nowrap ${activeTab === "time" ? "text-white border-b-2 border-[#9C6A4B]" : "text-[#9C6A4B]"}`}
            onClick={() => setActiveTab("time")}
          >
            时间卦
          </button>
          <button
            className={`py-2 px-4 font-serif whitespace-nowrap ${activeTab === "random" ? "text-white border-b-2 border-[#9C6A4B]" : "text-[#9C6A4B]"}`}
            onClick={() => setActiveTab("random")}
          >
            随机卦
          </button>
          <button
            className={`py-2 px-4 font-serif whitespace-nowrap ${activeTab === "dayan" ? "text-white border-b-2 border-[#9C6A4B]" : "text-[#9C6A4B]"}`}
            onClick={() => setActiveTab("dayan")}
          >
            大衍筮法
          </button>
        </div>

        {/* 占卜操作区 */}
        <div className="bg-[#2A2A2A] p-6 rounded-lg shadow-lg mb-8">
          {activeTab === "coin" && <CoinDivination onComplete={handleDivinationComplete} />}
          {activeTab === "time" && <TimeDivination onComplete={handleDivinationComplete} />}
          {activeTab === "random" && <RandomDivination onComplete={handleDivinationComplete} />}
          {activeTab === "dayan" && <DayanDivination onComplete={handleDivinationComplete} />}
        </div>

        {/* 结果预览区 */}
        {result && (
          <div className="bg-[#2A2A2A] p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-serif font-bold text-[#9C6A4B] mb-4">占卜结果</h3>
            <p className="text-gray-300 mb-4">您得到了第 {result} 卦</p>
            <button
              className="bg-[#9C6A4B] text-white px-4 py-2 rounded hover:bg-[#8C5A3B] transition-colors"
              onClick={handleViewInterpretation}
            >
              查看解读
            </button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

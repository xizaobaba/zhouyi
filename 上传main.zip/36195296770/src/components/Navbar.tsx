import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="bg-[#1A1A1A] text-[#9C6A4B] p-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 rounded-full bg-[#9C6A4B] flex items-center justify-center">
            <i className="fa-solid fa-yin-yang text-white text-xl"></i>
          </div>
          <span className="font-serif text-xl font-bold">周易占卜</span>
        </div>
        <div className="hidden md:flex space-x-6">
          <Link to="/" className="hover:text-white transition-colors">首页</Link>
          <Link to="/divination" className="hover:text-white transition-colors">占卜</Link>
          <Link to="/my-hexagrams" className="hover:text-white transition-colors">我的卦象</Link>
          <Link to="/culture" className="hover:text-white transition-colors">易经文化</Link>
        </div>
      </div>
    </nav>
  );
}

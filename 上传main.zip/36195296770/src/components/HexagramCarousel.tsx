import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { popularHexagrams } from "@/lib/mockData";

export default function HexagramCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % popularHexagrams.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-12 bg-[#1A1A1A]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-serif font-bold text-[#9C6A4B] mb-8 text-center">
          热门卦象
        </h2>
        <div className="relative overflow-hidden h-96">
          <div
            className="flex transition-transform duration-1000 ease-[cubic-bezier(0.25,0.1,0.25,1)]"
            style={{
              transform: `translateX(-${currentIndex * 100}%)`,
              width: `${popularHexagrams.length * 100}%`
            }}
          >
            {popularHexagrams.map((hexagram) => (
              hexagram && (
                <div
                  key={hexagram.id}
                  className="w-full flex-shrink-0 flex justify-center"
                >
                  <Link
                    to={`/hexagram/${hexagram.id}`}
                    className="block w-full max-w-md"
                  >
                    <div className="bg-[#2A2A2A] p-6 rounded-lg shadow-lg h-80 flex flex-col items-center justify-center">
                      <img
                        src={hexagram.image}
                        alt={hexagram.name}
                        className="w-32 h-32 object-contain mb-4"
                      />
                      <h3 className="text-2xl font-serif font-bold text-white mb-2">
                        {hexagram.name} {hexagram.symbol}
                      </h3>
                      <p className="text-gray-300 text-center">
                        {hexagram.description}
                      </p>
                    </div>
                  </Link>
                </div>
              )
            ))}
          </div>
        </div>
        <div className="flex justify-center mt-6 space-x-2">
          {popularHexagrams.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full ${currentIndex === index ? 'bg-[#9C6A4B]' : 'bg-gray-500'}`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

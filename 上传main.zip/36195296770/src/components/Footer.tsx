export default function Footer() {
  return (
    <footer className="bg-[#1A1A1A] text-[#9C6A4B] py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="font-serif">© 2025 周易占卜网 版权所有</p>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-white transition-colors">
              <i className="fa-brands fa-weixin text-xl"></i>
            </a>
            <a href="#" className="hover:text-white transition-colors">
              <i className="fa-brands fa-weibo text-xl"></i>
            </a>
            <a href="#" className="hover:text-white transition-colors">
              <i className="fa-solid fa-envelope text-xl"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

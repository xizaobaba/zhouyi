
// 64卦完整数据
export const hexagramData = [
  {
    id: 1,
    name: "乾卦",
    symbol: "䷀",
    description: "天行健，君子以自强不息",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E4%B9%BE%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=4656984d569284e946bc237e6bf35c49",
    classicText: "元亨利贞。象曰：天行健，君子以自强不息。",
    modernInterpretation: "乾卦象征天，代表创造、领导力和积极进取的精神。当前阶段适合大胆行动，发挥领导才能，但要注意保持正直和坚持原则。",
    aiAnalysis: {
      career: "事业发展处于上升期，适合开拓新领域或承担领导职责。保持积极主动的态度，但避免过于强势。",
      love: "感情方面需要主动表达，单身者有机会遇到理想伴侣，已有伴侣者关系将更加稳固。",
      health: "身体状况良好，但要注意劳逸结合，避免过度劳累导致免疫力下降。"
    }
  },
  {
    id: 2,
    name: "坤卦",
    symbol: "䷁",
    description: "地势坤，君子以厚德载物",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%9D%A4%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=59cf2dc7ee4fb586b5907e24b195ca98",
    classicText: "坤，元亨，利牝马之贞。君子有攸往，先迷后得主，利西南得朋，东北丧朋。安贞吉。",
    modernInterpretation: "坤卦象征地，代表包容、耐心和滋养的力量。当前阶段更适合稳健发展，培养耐心，注重团队合作而非个人表现。",
    aiAnalysis: {
      career: "适合从事支持性工作或团队合作，不宜强求出头。积累经验和人脉更为重要。",
      love: "感情需要耐心培养，单身者不宜急于求成，已有伴侣者要多包容理解对方。",
      health: "注意脾胃健康，饮食要规律，可适当增加温和的运动如瑜伽或散步。"
    }
  },
  {
    id: 3,
    name: "屯卦",
    symbol: "䷂",
    description: "云雷屯，君子以经纶",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%B1%AF%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=94d2ebb3ed965e6cf3df731c7a64b06c",
    classicText: "屯，元亨利贞。勿用有攸往，利建侯。",
    modernInterpretation: "屯卦象征万物初生时的艰难，提醒我们在初创阶段要谨慎行事，打好基础。",
    aiAnalysis: {
      career: "事业处于初创阶段，需要耐心积累，不宜急于求成。",
      love: "感情关系刚开始，需要时间培养，不宜操之过急。",
      health: "注意基础健康，预防小病积累成大病。"
    }
  },
  {
    id: 4,
    name: "蒙卦",
    symbol: "䷃",
    description: "山下出泉，蒙。君子以果行育德",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E8%92%99%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=a162cc30b7d7e31045dd2b30474cb88b",
    classicText: "蒙，亨。匪我求童蒙，童蒙求我。初筮告，再三渎，渎则不告。利贞。",
    modernInterpretation: "蒙卦象征启蒙教育，强调学习的重要性，提醒我们要保持谦虚好学的态度。",
    aiAnalysis: {
      career: "需要不断学习新知识，提升专业技能。",
      love: "感情上需要更多沟通和理解。",
      health: "注意用脑过度，适当休息。"
    }
  },
  {
    id: 5,
    name: "需卦",
    symbol: "䷄",
    description: "云上于天，需。君子以饮食宴乐",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E9%9C%80%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=425ca7956eeb97a0bcdabd7e81394ad3",
    classicText: "需，有孚，光亨，贞吉。利涉大川。",
    modernInterpretation: "需卦象征等待时机，提醒我们在条件不成熟时需要耐心等待，同时做好准备。",
    aiAnalysis: {
      career: "事业发展需要等待合适时机，不宜贸然行动。利用这段时间提升自身能力。",
      love: "感情发展需要时间，单身者不宜急于表白，已有伴侣者要给对方空间。",
      health: "注意休息和饮食调养，预防慢性疾病。"
    }
  },
  {
    id: 6,
    name: "讼卦",
    symbol: "䷅",
    description: "天与水违行，讼。君子以作事谋始",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E8%AE%BC%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=3b57d69567d34e850ff367d2887136d8",
    classicText: "讼，有孚窒惕，中吉终凶。利见大人，不利涉大川。",
    modernInterpretation: "讼卦象征争议和矛盾，提醒我们要避免不必要的争执，寻求和平解决之道。",
    aiAnalysis: {
      career: "职场可能遇到争议，保持冷静理性，寻求上级或专业人士调解。",
      love: "感情中避免争吵，多沟通理解对方立场。",
      health: "注意情绪管理，避免因压力导致身心不适。"
    }
  },
  {
    id: 7,
    name: "师卦",
    symbol: "䷆",
    description: "地中有水，师。君子以容民畜众",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%B8%88%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=5d7bdd209912fb6bb1f1b592fc8053bc",
    classicText: "师，贞，丈人吉，无咎。",
    modernInterpretation: "师卦象征军队和领导力，提醒我们在组织和管理中需要公正和纪律。",
    aiAnalysis: {
      career: "适合担任领导角色，但需公正无私，方能获得团队信任。",
      love: "感情中需要更多责任感和承诺，单身者可能遇到成熟稳重的对象。",
      health: "注意骨骼和关节健康，适当增加钙质摄入。"
    }
  },
  {
    id: 8,
    name: "比卦",
    symbol: "䷇",
    description: "地上有水，比。先王以建万国，亲诸侯",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E6%AF%94%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=0c4c680505c73e15a4fb996743433651",
    classicText: "比，吉。原筮，元永贞，无咎。不宁方来，后夫凶。",
    modernInterpretation: "比卦象征亲密关系和合作，提醒我们建立互信互助的人际关系。",
    aiAnalysis: {
      career: "适合团队合作，建立良好的人际关系网络对事业发展有利。",
      love: "感情关系和谐，适合进一步发展承诺关系。",
      health: "注意肾脏和泌尿系统健康，多喝水保持水分。"
    }
  },

  {
    id: 62,
    name: "小过卦",
    symbol: "䷽",
    description: "山上有雷，小过。君子以行过乎恭，丧过乎哀，用过乎俭",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%B0%8F%E8%BF%87%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=5c7b89cc3ec2b0376e00416eb9355742",
    classicText: "小过，亨，利贞。可小事，不可大事。飞鸟遗之音，不宜上宜下，大吉。",
    modernInterpretation: "小过卦象征小的过度，提醒我们在小事上可以灵活处理，但大事上要谨慎守正。",
    aiAnalysis: {
      career: "适合处理细节工作，重大决策需谨慎。",
      love: "小浪漫可以增进感情，但不要过度干涉对方生活。",
      health: "注意小病小痛，及时调理预防加重。"
    }
  },
  {
    id: 63,
    name: "既济卦",
    symbol: "䷾",
    description: "水在火上，既济。君子以思患而豫防之",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E6%97%A2%E6%B5%8E%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=b0b062f31d772b176b69aeadc03c0a73",
    classicText: "既济，亨小，利贞。初吉终乱。",
    modernInterpretation: "既济卦象征事情已经完成，提醒我们在成功之后仍要保持警惕，预防可能的变故。",
    aiAnalysis: {
      career: "项目已完成，但仍需关注后续发展，防止功亏一篑。",
      love: "感情关系稳定，但需注意保持新鲜感。",
      health: "康复期要注意巩固疗效，防止复发。"
    }
  },
  {
    id: 64,
    name: "未济卦",
    symbol: "䷿",
    description: "火在水上，未济。君子以慎辨物居方",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E6%9C%AA%E6%B5%8E%E5%8D%A6%E7%AC%A6%E5%8F%B7%2C%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%B0%94%E5%A2%A8%E9%A3%8E%E6%A0%BC%2C%E9%BB%91%E8%89%B2%E8%83%8C%E6%99%AF&sign=0f722c8af87a00539dc81073f28915c5",
    classicText: "未济，亨，小狐汔济，濡其尾，无攸利。",
    modernInterpretation: "未济卦象征事情尚未完成，提醒我们虽然接近成功但仍需谨慎。当前阶段需要耐心和坚持，避免功亏一篑。",
    aiAnalysis: {
      career: "项目接近完成但仍有变数，需注意细节和团队协作，避免因小失大。",
      love: "感情发展可能遇到小波折，需要更多沟通和理解来克服困难。",
      health: "康复中的患者要注意巩固疗效，健康人群则需预防季节性疾病的侵袭。"
    }
  }

];

// 初始化用户数据
export function initUserData() {
  if (!localStorage.getItem("userData")) {
    localStorage.setItem("userData", JSON.stringify({
      avatar: "",
      nickname: "易经爱好者", 
      joinDate: new Date().toISOString()
    }));
  }
  
  if (!localStorage.getItem("divinationRecords")) {
    localStorage.setItem("divinationRecords", JSON.stringify([]));
  }
  
  if (!localStorage.getItem("favorites")) {
    localStorage.setItem("favorites", JSON.stringify([]));
  }
}

// 初始化数据
initUserData();


// 占卜方法数据
export const divinationMethods = [
  {
    id: "coin",
    name: "金钱卦",
    description: "通过抛掷铜钱进行占卜",
    icon: "fa-solid fa-coins"
  },
  {
    id: "time",
    name: "时间卦",
    description: "根据当前时间生成卦象",
    icon: "fa-solid fa-clock"
  },
  {
    id: "random",
    name: "随机卦",
    description: "随机生成一个卦象",
    icon: "fa-solid fa-shuffle"
  },
  {
    id: "dayan",
    name: "大衍筮法",
    description: "传统蓍草占卜方法",
    icon: "fa-solid fa-leaf"
  }
];

// 热门卦象数据
export const popularHexagrams = [
  hexagramData[0],  // 乾卦
  hexagramData[1],  // 坤卦
  hexagramData[11], // 泰卦
  hexagramData[12], // 否卦
  hexagramData[29], // 坎卦
  hexagramData[30]  // 离卦
];

/**
 * 生成卦象ID
 * @param method 占卜方法 ('coin' | 'time' | 'random')
 * @param data 占卜数据 (铜钱结果数组或时间字符串)
 * @returns 卦象ID (1-64)
 */
export function generateHexagram(method: string, data?: any): number {
  switch (method) {
    case "coin":
      // 铜钱卦: 根据阴阳结果生成卦象ID
      if (Array.isArray(data) && data.length === 6) {
        const binaryStr = data.map(coin => coin === 1 ? "1" : "0").join("");
        return parseInt(binaryStr, 2) % 64 + 1;
      }
      break;
    case "time":
      // 时间卦: 根据时间戳生成卦象ID
      if (typeof data === "string") {
        const timestamp = new Date(data).getTime();
        return Math.abs(timestamp % 64) + 1;
      }
      break;
    case "random":
      // 随机卦: 生成1-64的随机数
      return Math.floor(Math.random() * 64) + 1;
    case "dayan":
      // 大衍筮法: 生成1-64的随机数 (模拟传统方法结果)
      return Math.floor(Math.random() * 64) + 1;
  }
  // 默认返回随机卦
  return Math.floor(Math.random() * 64) + 1;
}
